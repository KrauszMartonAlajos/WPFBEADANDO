﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

using LiveCharts;
using LiveCharts.Wpf;

namespace Beadando_KM
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private DateTime kezd;
        private DispatcherTimer tempido = new DispatcherTimer();
        private DispatcherTimer korTemp = new DispatcherTimer();
        
        public MainWindow()
        {
            InitializeComponent();
            grafikon.Series = new SeriesCollection
            {
                new LineSeries
                {
                    Title = "Kör idők",
                    Values = new ChartValues<double> {}
                },
            };
            TemaMegjelenit();
            tempido.Interval = TimeSpan.FromMilliseconds(1);
            tempido.Tick += TIKKELES;
            korTemp.Interval = TimeSpan.FromMilliseconds(1);
            korTemp.Tick += TIKKELESKOR;
        }

        public SeriesCollection SeriesCollection { get; set; }
        public string[] Labels { get; set; }
        public Func<double, string> YFormatter { get; set; }

        //Kell még az egyszerre egy ablakot nyithat meg cucc

        private void TemaMegjelenit()
        {
            int ertek = Properties.Settings.Default.TemaSelect;
            
            if (ertek == 1)
            {
                temamegj.Content = "'Pride'";
                //SetImageSource("C:\\Users\\xboxh\\OneDrive\\Asztali gép\\Stopperóra\\Beadando_KM\\Beadando_KM/pride.png");
                GRIDDY.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#0000F9"));
                start_stop.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF0018"));
                reset.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FFA52C"));
                idok.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FFFF41"));
            }
            else if (ertek == 2)
            {
                temamegj.Content = "'Nagy Magyar'";
                //SetImageSource("C:\\Users\\xboxh\\OneDrive\\Asztali gép\\Stopperóra\\Beadando_KM\\Beadando_KM/magyar.png");
                GRIDDY.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#31468B"));  // Hungarian flag blue
                start_stop.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#CE1126"));  // Hungarian flag red
                reset.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#4CAF50"));  // Hungarian countryside green
                idok.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FFC61E"));  // Traditional Hungarian embroidery gold
            }
            else if (ertek == 3)
            {
                temamegj.Content = "'Gucci'";
                //SetImageSource("C:\\Users\\xboxh\\OneDrive\\Asztali gép\\Stopperóra\\Beadando_KM\\Beadando_KM/gucci.png");
                GRIDDY.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#0F4C81"));  // Gucci dark blue
                start_stop.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF1800"));  // Gucci red
                reset.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FFA52C"));  // Gucci gold
                idok.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#D6BD1E"));  // Gucci yellow
            }
        }

        private void SetImageSource(string imagePath)
        {
            BitmapImage bitmap = new BitmapImage();
            bitmap.BeginInit();
            bitmap.UriSource = new Uri(imagePath, UriKind.RelativeOrAbsolute);
            bitmap.EndInit();
            kep.Source = bitmap;
        }
        

        private void TIKKELES(object sender, EventArgs e)
        {
            TimeSpan elapsed = DateTime.Now - kezd;
            timer.Content = string.Format("{0:mm\\:ss\\:fff}", elapsed);
        }

        private void TIKKELESKOR(object sender, EventArgs e)
        {
            TimeSpan elapsed = DateTime.Now - kor;
            KorTimer.Content = string.Format("{0:mm\\:ss\\:fff}", elapsed);
        }

        bool start = true;
        bool koztesfn = false;
        private void Button_Click(object sender, RoutedEventArgs e)
        {

            if (start)
            {
                //START
                kezd = DateTime.Now;
                kor = DateTime.Now;
                tempido.Start();
                start = !start;
                start_stop.Content = "Stop";
                idok.Items.Clear();
                korTemp.Start();
            }
            else if (!start && !koztesfn)
            {
                //STOP
                korTemp.Stop();
                tempido.Stop();
                megallt = DateTime.Now;
                start_stop.Content = "Folytatas";
                reset.Content = "VISSZAALLIT";
                koztesfn = true;
                MaxEsMinIdoKivalaszt();
            }
            else if (start_stop.Content == "Folytatas")
            {
                //FOLYTATAS
                DateTime folytido = DateTime.Now;
                kezd += (folytido - megallt);
                kor += (folytido - megallt);
                start = false;
                start_stop.Content = "Stop";
                koztesfn = false;
                reset.Content = "KÖR";
                tempido.Start();
                korTemp.Start();
            }

        }

        private void MaxEsMinIdoKivalaszt()
        {
            //try
            //{
            //    MessageBox.Show(idok_list[0]);
            //}
            //catch
            //{
            //    MessageBox.Show("Nincs idő kiválasztva");
            //}

            //mindig az első és utolsó idő lesz a min és max??????
            
            //List<TimeSpan> idok_ido = idok_list.Select(timeStr => TimeSpan.Parse(timeStr)).ToList();
            //TimeSpan min = idok_ido.Min();
            //TimeSpan max = idok_ido.Max();

            //string mmax = max.ToString(@"mm\:ss\:fff") + "+MAX+";
            //string mmin = min.ToString(@"mm\:ss\:fff") + "-MIN-";

            //int imin = idok_list.IndexOf(min.ToString(@"mm\:ss\:fff"));
            //int imax = idok_list.IndexOf(max.ToString(@"mm\:ss\:fff"));

            //idok_list[imin] = mmax;
            //idok_list[imax] = mmin;
        }

        List<string> idok_list = new List<string>();
        List<string> koridok = new List<string>();
        int korok = 0;
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            
            if (!start && koztesfn)
            {
                //itt kell resetelni az időt
                korok = 0;
                start = true;
                start_stop.Content = "START";
                koztesfn = false;
                reset.Content = "KÖR";
                timer.Content = "00:00:000";
                KorTimer.Content = "00:00:000";
                idok_list.Clear();
                grafikon.Series[0].Values.Clear();
            }
            else 
            {
                kor = DateTime.Now;
                korok++;
                string aktkor = Convert.ToString(KorTimer.Content);
                idok_list.Add(aktkor);
                koridok.Add(aktkor);
                idok.Items.Add(String.Format(Convert.ToString(korok)+". "+aktkor+" "+timer.Content));
                GrafAbrazol();
            }
        }
        public DateTime megallt;
        public DateTime kor;

        private void GrafAbrazol()
        {
            ChartValues<double> atszamoltidok = new ChartValues<double>();
            for (int i = 0; i < idok_list.Count(); i++)
            {
                atszamoltidok.Add(IdoMpBeSzamolas(idok_list[i]));
            }
            grafikon.Series[0].Values = atszamoltidok;
        }


        private double IdoMpBeSzamolas(string be)
        {
            string[] parts = be.Split(':');
            int minutes = Convert.ToInt32(parts[0]);
            int seconds = Convert.ToInt32(parts[1]);
            int milliseconds = Convert.ToInt32(parts[2]);
            double mp = minutes * 60 * 1000 + seconds * 1000 + milliseconds;
            mp /= 1000.0;
            return mp;
        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            Properties.Settings.Default.TemaSelect = 1;
            Properties.Settings.Default.Save();
            TemaMegjelenit();
        }

        private void RadioButton_Checked_1(object sender, RoutedEventArgs e)
        {
            Properties.Settings.Default.TemaSelect = 2;
            Properties.Settings.Default.Save();
            TemaMegjelenit();
        }

        private void RadioButton_Checked_2(object sender, RoutedEventArgs e)
        {
            Properties.Settings.Default.TemaSelect = 3;
            Properties.Settings.Default.Save();
            TemaMegjelenit();
        }
    }
}
