﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

using LiveCharts;
using LiveCharts.Wpf;

namespace Beadando_KM
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private DateTime kezd;
        private DispatcherTimer tempido = new DispatcherTimer();
        

        public MainWindow()
        {
            InitializeComponent();

            TemaMegjelenit();
            tempido.Interval = TimeSpan.FromMilliseconds(1);
            tempido.Tick += TIKKELES;
        }

        public SeriesCollection SeriesCollection { get; set; }
        public string[] Labels { get; set; }
        public Func<double, string> YFormatter { get; set; }


        private void TemaMegjelenit()
        {
            int ertek = Properties.Settings.Default.TemaSelect;
            
            if (ertek == 1)
            {
                ////téma 1 PRIDE
                
                temamegj.Content = "'Pride'";
                SetImageSource("H:/STOPPER(IMÁDOM)/WPFBEADANDO/Beadando_KM/pride.png");
                GRIDDY.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#0000F9"));
                start_stop.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF0018"));
                reset.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FFA52C"));
                idok.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FFFF41"));
                diagramm.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#861F41"));
            }
            else if (ertek == 2)
            {
                //téma 2
                temamegj.Content = "'Nagy Magyar'";
                SetImageSource("H:/STOPPER(IMÁDOM)/WPFBEADANDO/Beadando_KM/magyar.png");
                GRIDDY.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#31468B"));  // Hungarian flag blue
                start_stop.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#CE1126"));  // Hungarian flag red
                reset.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#4CAF50"));  // Hungarian countryside green
                idok.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FFC61E"));  // Traditional Hungarian embroidery gold
                diagramm.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#005A9C"));  // Danube blue
            }
            else if (ertek == 3)
            {
                //téma 3
                temamegj.Content = "'Gucci'";
                SetImageSource("H:/STOPPER(IMÁDOM)/WPFBEADANDO/Beadando_KM/gucci.png");
                GRIDDY.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#0F4C81"));  // Gucci dark blue
                start_stop.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF1800"));  // Gucci red
                reset.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FFA52C"));  // Gucci gold
                idok.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#D6BD1E"));  // Gucci yellow
                diagramm.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#5B0E2D"));  // Gucci dark purple
            }
        }

        private void SetImageSource(string imagePath)
        {
            BitmapImage bitmap = new BitmapImage();
            bitmap.BeginInit();
            bitmap.UriSource = new Uri(imagePath, UriKind.RelativeOrAbsolute);
            bitmap.EndInit();
            kep.Source = bitmap;
        }
        

        private void TIKKELES(object sender, EventArgs e)
        {
            TimeSpan elapsed = DateTime.Now - kezd;
            timer.Content = string.Format("{0:mm\\:ss\\:fff}", elapsed);
        }

        bool start = true;
        bool koztesfn = false;
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //idok.Items.Clear();
            


            if (start)
            {
                kezd = DateTime.Now;
                tempido.Start();
                start = !start;
                start_stop.Content = "Stop";
                idok.Items.Clear();
            }
            else if (!start && !koztesfn)
            {
                tempido.Stop();
                start_stop.Content = "Folytatas";
                reset.Content = "VISSZAALLIT";
                koztesfn = true;

            }
            else if (koztesfn && start)
            {
                reset.Content = "VISSZAALLIT";
                start_stop.Content = "START";
                tempido.Start();
                MessageBox.Show("ehsf");
                start = !start;
            }
            else if (start_stop.Content == "Folytatas")
            {
                start = false;
                start_stop.Content = "Stop";
                koztesfn = false;
                reset.Content = "KÖR";
                tempido.Start();
            }
            //START/STOP
            //SZar megy tovább az idő amíg áll a stopper
        }

        List<string> idok_list = new List<string>();
        int korok = 0;
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (!start && koztesfn)
            {
                //itt kell resetelni az időt
                korok = 0;
                start = true;
                start_stop.Content = "START";
                koztesfn = false;
                reset.Content = "KÖR";
                timer.Content = "00:00:000";
            }
            else 
            {
                korok++;
                idok_list.Add(Convert.ToString(timer.Content));
                idok.Items.Add(String.Format(Convert.ToString(korok)+". "+timer.Content));

            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            //Diagramm
            //Vonal diagramm
            //Ki kell választani a maximum időt az lessz a teljes egység és abból arányosan jön le a többi
            AddDataToChart();
        }

        private void AddDataToChart()
        {
            // Example data for the chart
            SeriesCollection = new SeriesCollection
            {
                new LineSeries
                {
                    Title = "Series 1",
                    Values = new ChartValues<double> { 4, 6, 5, 2, 7 }
                },
            };
            // Example formatter for Y-axis labels
            YFormatter = value => value.ToString("N"); // Format as number
        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            //0 - téma 1 
            Properties.Settings.Default.TemaSelect = 1;
            Properties.Settings.Default.Save();
            TemaMegjelenit();
        }

        private void RadioButton_Checked_1(object sender, RoutedEventArgs e)
        {
            //1 - téma 2
            Properties.Settings.Default.TemaSelect = 2;
            Properties.Settings.Default.Save();
            TemaMegjelenit();
        }

        private void RadioButton_Checked_2(object sender, RoutedEventArgs e)
        {
            //2 - téma 3
            Properties.Settings.Default.TemaSelect = 3;
            Properties.Settings.Default.Save();
            TemaMegjelenit();
        }
    }
}
