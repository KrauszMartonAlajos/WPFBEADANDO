﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;

namespace Beadando_KM
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private const string MutexName = "Mutexecske";
        private Mutex singleInstanceMutex;
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            singleInstanceMutex = new Mutex(true, MutexName, out bool uj);

            if (!uj)
            {
                MessageBox.Show("Már egy példány fut!", "Figyelmeztetés");
                Shutdown();
            }
        }

        protected override void OnExit(ExitEventArgs e)
        {
            singleInstanceMutex?.Close();
            base.OnExit(e);
        }
    }

}
