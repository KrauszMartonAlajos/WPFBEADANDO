﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Windows.Forms.DataVisualization.Charting;

namespace Beadando_KM
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private DateTime kezd;
        private DispatcherTimer tempido = new DispatcherTimer();
        

        public MainWindow()
        {
            InitializeComponent();

            TemaMegjelenit();
            tempido.Interval = TimeSpan.FromMilliseconds(1);
            tempido.Tick += TIKKELES;
        }

        private void AddDataToChart()
        {
            // Adding some sample data points to the series
            //mcChart.Series["MonthlyCount"].Points.AddXY("January", 100);
            //mcChart.Series["MonthlyCount"].Points.AddXY("February", 150);
            //mcChart.Series["MonthlyCount"].Points.AddXY("March", 200);
            //mcChart.Series["MonthlyCount"].Points.AddXY("April", 180);
            // Add more data points as needed
        }
        private void TemaMegjelenit()
        {
            int ertek = Properties.Settings.Default.TemaSelect;
            
            if (ertek == 1)
            {
                ////téma 1 PRIDE
                
                temamegj.Content = "'Pride'";
                SetImageSource("H:/STOPPERGEC/WPFBEADANDO/Beadando_KM/pride.png");
                GRIDDY.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#0000F9"));
                start_stop.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FF0018"));
                reset.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FFA52C"));
                idok.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#FFFF41"));
                Diagramm.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#008018"));
                diagramm.Background = (SolidColorBrush)(new BrushConverter().ConvertFrom("#861F41"));
            }
            else if (ertek == 2)
            {
                //téma 2
                temamegj.Content = "'Nagy Magyar'";
            }
            else if (ertek == 3)
            {
                //téma 3
                temamegj.Content = "'Gucci'";
            }
        }

        private void SetImageSource(string imagePath)
        {
            BitmapImage bitmap = new BitmapImage();
            bitmap.BeginInit();
            bitmap.UriSource = new Uri(imagePath, UriKind.RelativeOrAbsolute);
            bitmap.EndInit();
            kep.Source = bitmap;
        }
        

        private void TIKKELES(object sender, EventArgs e)
        {
            TimeSpan elapsed = DateTime.Now - kezd;
            timer.Content = string.Format("{0:mm\\:ss\\:fff}", elapsed);
        }

        bool start = true;
        bool koztesfn = false;
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //idok.Items.Clear();
            


            if (start)
            {
                kezd = DateTime.Now;
                tempido.Start();
                start = !start;
                start_stop.Content = "Stop";
                idok.Items.Clear();
            }
            else if (!start && !koztesfn)
            {
                tempido.Stop();
                start_stop.Content = "Folytatas";
                reset.Content = "VISSZAALLIT";
                koztesfn = true;

            }
            else if (koztesfn && start)
            {
                reset.Content = "VISSZAALLIT";
                start_stop.Content = "START";
                tempido.Start();
                MessageBox.Show("ehsf");
                start = !start;
            }
            else if (start_stop.Content == "Folytatas")
            {
                start = false;
                start_stop.Content = "Stop";
                koztesfn = false;
                reset.Content = "KÖR";
                tempido.Start();
            }
            //START/STOP
        }

        List<string> idok_list = new List<string>();
        int korok = 0;
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (!start && koztesfn)
            {
                //itt kell resetelni az időt
                korok = 0;
                start = true;
                start_stop.Content = "START";
                koztesfn = false;
                reset.Content = "KÖR";
                timer.Content = "00:00:000";
            }
            else 
            {
                korok++;
                idok_list.Add(Convert.ToString(timer.Content));
                idok.Items.Add(String.Format(Convert.ToString(korok)+". "+timer.Content));

            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            //Diagramm
            AddDataToChart();
            //Vonal diagramm
            //Ki kell választani a maximum időt az lessz a teljes egység és abból arányosan jön le a többi
        }

        

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            //0 - téma 1 
            Properties.Settings.Default.TemaSelect = 1;
            Properties.Settings.Default.Save();
            TemaMegjelenit();
        }

        private void RadioButton_Checked_1(object sender, RoutedEventArgs e)
        {
            //1 - téma 2
            Properties.Settings.Default.TemaSelect = 2;
            Properties.Settings.Default.Save();
            TemaMegjelenit();
        }

        private void RadioButton_Checked_2(object sender, RoutedEventArgs e)
        {
            //2 - téma 3
            Properties.Settings.Default.TemaSelect = 3;
            Properties.Settings.Default.Save();
            TemaMegjelenit();
        }
    }
}
